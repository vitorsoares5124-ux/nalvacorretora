LOVFY V2 — versão 32.0.6

INSTALAÇÃO
1. Extraia a pasta Lovfy.
2. Abra chrome://extensions.
3. Ative o Modo do desenvolvedor.
4. Clique em "Carregar sem compactação".
5. Selecione a pasta Lovfy.
6. Clique no ícone da extensão para abrir o painel.

LICENÇA
Chave configurada: LOVFY2026v3
A validação é local e não usa servidor externo.

CORREÇÃO DE ABERTURA
O ícone da extensão agora abre popup.html (420 x 600) e não redireciona automaticamente para lovable.dev.
