// Lovfy — licenciamento local simples.
// Somente a chave abaixo desbloqueia a extensão. Nenhuma validação externa é feita.
(function () {
  "use strict";

  const LOVFY_LICENSE_KEY = "LOVFY2026v3";

  const MESSAGES = Object.freeze({
    ok: "Licença ativada. Bem-vindo ao Lovfy.",
    not_found: "Chave inválida. Verifique o código e tente novamente.",
    empty: "Digite sua chave de licença para continuar."
  });

  function safeSessionId(key) {
    try {
      const k = String(key || "").trim();
      let h = 0;
      for (let i = 0; i < k.length; i++) {
        h = ((h << 5) - h + k.charCodeAt(i)) | 0;
      }
      return "lovfy_" + Math.abs(h).toString(36) + "_" + k.length;
    } catch (_) {
      return "lovfy_local";
    }
  }

  function makeValidResponse(key) {
    return Object.freeze({
      valid: true,
      reason: null,
      message: MESSAGES.ok,
      expires_at: null,
      activated_at: new Date().toISOString(),
      status: "active",
      license_type: "paid",
      lifetime: true,
      session_id: safeSessionId(key),
      user_name: "Usuario",
      online_count: 0,
      plan: "lifetime"
    });
  }

  function makeInvalidResponse(reason, message) {
    return Object.freeze({
      valid: false,
      reason: reason || "invalid",
      message: message || MESSAGES.not_found,
      expires_at: null,
      activated_at: null,
      status: reason || "invalid",
      license_type: "paid",
      lifetime: false,
      session_id: null,
      user_name: null,
      online_count: 0,
      plan: null
    });
  }

  async function lvbValidate(fetcher, key, deviceId) {
    const cleaned = String(key == null ? "" : key).trim();

    if (!cleaned) {
      return makeInvalidResponse("not_found", MESSAGES.empty);
    }

    if (cleaned !== LOVFY_LICENSE_KEY) {
      return makeInvalidResponse("not_found", MESSAGES.not_found);
    }

    return makeValidResponse(cleaned);
  }

  const root = (typeof window !== "undefined" && window) ||
               (typeof self !== "undefined" && self) ||
               (typeof globalThis !== "undefined" && globalThis) || {};

  try {
    root.LOVFY_LICENSE_KEY_REQUIRED = LOVFY_LICENSE_KEY;
    root.lvbValidate = lvbValidate;
  } catch (e) {
    console.warn("[LOVFY] Falha ao iniciar licenciamento local:", e);
  }
})();
